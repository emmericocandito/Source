# React-Veltrix-Template5

Check for node-sass version: It should be 7.0.1

### To run the Admin template

git clone https://github.com/PoorvikaTemp04/React-Veltrix-Template5 \
cd React-Veltrix-Template5/Admin \
npm install node-sass \
npm run start 

### To run the User template

cd React-Veltrix-Template5/StarterKit \
npm install node-sass \
npm run start 
